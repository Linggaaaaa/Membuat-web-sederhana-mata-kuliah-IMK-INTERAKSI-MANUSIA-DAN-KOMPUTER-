<?php include("Admin/inc_header.php")?>
<div style="background-color: red;font-size:large;padding:50px;color:#FFFFFF;text-align:center">
Selamat datang di halaman rahasia. Hanya yang sudah login yang bisa akses halaman ini.
</div>
<?php include("Admin/inc_footer.php")?>