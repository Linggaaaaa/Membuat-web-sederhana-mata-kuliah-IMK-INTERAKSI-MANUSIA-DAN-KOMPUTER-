<?php include("Admin/inc_header.php")?>
<style>
    table {
        width: 600px;
    }

    @media screen and (mas-width: 700px){
        table {

        }
    }
    table td {
        padding: 5px;
    }
    td.label { width: 40%;}
    .input {
        border: 1px solid #CCCCCC;
        background-color: #dfdfdf
        border-radius: 5px;
        padding: 10px;
        width: 100%;  
    }
    input.tbl-biru {
        border: none;
        background-color: #3f72af;
        border-radius: 20px;
        margin-top: 20px;
        padding: 15px 20px 15px 20px;
        color: #FFFFFF;
        cursor:pointer;
        font-weight: bold; 
    }
    input.tbl-biru:hover {
        background-color: #fc5185;
        text-decoration: none;
    }
    .error {
        padding: 20px;
        background-color: #F44336;
        color: #FFFFFF;
        margin-botom: 15px;
    }

    .sukses {
        padding: 20px;
        background-color: #2196F3;
        color: #FFFFFF;
        margin-botom: 15px;
    }

    .error ul { margin-left: 10px;}
</style>
<h3>Login ke halaman users</h3>
<?php 
$email      = "";
$password   = "";
$err        = "";

if(isset($_POST['login'])){
    $email      = $_POST['email'];
    $password   = $_POST['password'];

    if($email == '' or $password == ''){
        $err .= "<li>Silakan masukkan semua isian</li>";
    }else{
        $sql1   = "select * from users where email = '$email'";
        $q1     = mysqli_query($koneksi,$sql1);
        $r1     = mysqli_fetch_array($q1);
        $n1     = mysqli_num_rows($q1);

        if($r1['password'] != md5($password) && $n1 >0 && $r1['status'] == '1'){
            $err .= "<li>Password tidak sesuai</li>";
        }

        if($n1 < 1){
            $err .= "<li>Akun tidak ditemukan</li>";
        }

        if(empty($err)){
            header("location:Design.html");
            exit();
        }
    }
}  
?>
<?php if($err){ echo "<div class='error'><ul class='pesan'>$err</ul></div>";}?>
<form action="" method="POST">
    <table>
        <tr>
            <td class="label">Email</td>
            <td><input type="text" name="email" class="input" value="<?php echo $email?>"/></td>
        </tr>
        <tr>
            <td class="label">Password</td>
            <td><input type="password" name="password" class="input" /></td>
        </tr>
        <tr>
            <td></td>
            <td><input type="submit" name="login" value="Login" class="tbl-biru"/></td>
        </tr>
    </table>
</form>
<?php include("Admin/inc_footer.php")?>