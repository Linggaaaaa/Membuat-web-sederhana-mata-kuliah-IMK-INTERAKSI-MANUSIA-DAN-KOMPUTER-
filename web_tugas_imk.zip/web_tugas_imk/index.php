<!DOCTYPE html>
<html lang="en">
<head> 
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pembelajaran Otomotif Seru</title>
    <link rel="stylesheet" href="css/Style.css">
</head>
<body>
    <nav>
        <div class="wrapper">
            <div class="logo"><a href="">Otomotif Seru</a></div>
            <div class="menu">
                <ul>
                    <li><a href="#home">Home</a></li>
                    <li><a href="#contact">Contact</a></li>
                    <li><a href="pendaftaran.php" class="tbl-biru">Sign Up</a></li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="wrapper">
        <!-- untuk home -->
        <section id="home">
            <img src="https://img.freepik.com/premium-vector/skull-mascot-logo-design-vector-with-concept-style-badge-emblem-t-shirt-printing-skull-bikers-illustration_585271-357.jpg?w=826"/>
            <div class="kolom">
                <p class="deskripsi">Belajar Otomotif</p>
                <h2>Is not over, Until i win!</h2>
                <h3>Otomotif adalah berhubungan dengan sesuatu yang berputar dengan sendirinya (seperti motor dan sebagainya). Jadi, segala kendaraan yang mampu memindahkan dari satu lokasi ke lokasi lainnya. </h3>
            </div>
        </section>
    </div>

    <div id="contact">
        <div class="wrapper"></div>
            <div class="footer">
                <div class="footer-section">
                    <h3>About</h3>
                    <p>Kami menyediakan website pembelajaran interaktif</p>
                </div>
                <div class="footer-section">
                    <h3>Contact</h3>
                    <p>Silahkan contact kami ke nomor: 085774011530</p>
                </div>
                <div class="footer-section">
                    <h3>Social</h3>
                    <p><b>Gmail: </b>assydqireza22@gmail.com</p>
                </div>
            </div>
    </div>

    <div id="copyright">
        <div class="wrapper">
            &copy; 2022. <b>OtomotifSeru.</b> All Rights Reserved.
        </div>
    </div>

</body>
</html>