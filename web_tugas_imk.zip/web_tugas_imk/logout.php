<?php  
session_start();
unset($_SESSION['users_email']);
unset($_SESSION['users_nama_lengkap']);
session_destroy();
header("location: index.php");
?>